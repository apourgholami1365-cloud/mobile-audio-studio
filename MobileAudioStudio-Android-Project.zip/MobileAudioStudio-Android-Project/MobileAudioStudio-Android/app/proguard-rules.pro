# Keep JavascriptInterface methods
-keepclassmembers class com.audiostudio.mobile.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
