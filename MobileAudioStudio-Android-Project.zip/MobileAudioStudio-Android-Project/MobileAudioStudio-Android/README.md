# استودیو صوتی موبایل — پروژه اندروید (APK)

این پروژه شامل صفحه HTML شما در قالب یک اپلیکیشن بومی اندروید (Kotlin + WebView) است و موارد زیر در آن پیاده‌سازی شده است:
- انتخاب فایل صوتی از حافظه گوشی (`onShowFileChooser`)
- دسترسی میکروفون و ضبط صدا روی بستر امن (`WebViewAssetLoader` + `RECORD_AUDIO`)
- ذخیره مستقیم فایل‌های خروجی (WAV، MP3، AIFF، OGG و...) در پوشه `Downloads` گوشی (`AndroidBridge`)
- حفظ فایل در حال ویرایش هنگام چرخش صفحه و تم تاریک هماهنگ با صفحه (`#0d0f12`)

## روش ۱: ساخت APK بدون نصب Android Studio (از طریق GitHub Actions)
1. یک مخزن (Repository) جدید در GitHub بسازید.
2. محتویات داخل پوشه `MobileAudioStudio-Android` را در آن مخزن آپلود کنید (پوشه `.github` حتماً باید در ریشه مخزن باشد).
3. وارد تب **Actions** شوید و روی **Build Android APK** کلیک کرده و **Run workflow** را بزنید (یا با اولین Push به‌صورت خودکار اجرا می‌شود).
4. پس از حدود ۲ دقیقه، در بخش **Artifacts** فایل `MobileAudioStudio-debug-apk` را دانلود و روی گوشی نصب کنید.

## روش ۲: ساخت APK با Android Studio
1. پوشه `MobileAudioStudio-Android` را در **Android Studio** باز کنید.
2. صبر کنید Gradle sync کامل شود.
3. از منوی بالا مسیر `Build > Build Bundle(s) / APK(s) > Build APK(s)` را انتخاب کنید.
4. فایل APK در مسیر `app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.
